// Phoneme Visual Degradation phía client. Đồng bộ logic với backend/core/phoneme.py (R-06).
// Trả token để React render: {t, cls} với cls = '' | 'hide' | 'fade'.
//
// VI: theo ngữ âm tiếng Việt (R-04) — tách cluster trước, phân band tần số,
//     giữ nguyên âm + thanh điệu lâu nhất (Severe chỉ fade nguyên âm).
// EN: giữ engine cũ.

const HIGH = "HIGH", MID = "MID", LOW = "LOW", VOWEL = "VOWEL", OTHER = "OTHER";

const VI_CLUSTERS = [
  ["ngh", LOW], ["ng", LOW], ["nh", LOW], ["gh", LOW],
  ["ph", HIGH], ["th", HIGH], ["kh", HIGH],
  ["tr", MID], ["ch", MID], ["qu", MID],
];
const VI_SINGLE = {
  x: HIGH, s: HIGH, h: HIGH, v: HIGH, r: HIGH, d: HIGH,
  t: MID, c: MID, k: MID, q: MID, p: MID,
  g: LOW, m: LOW, n: LOW, l: LOW, b: LOW, "đ": LOW,
};
const DROP_BANDS = { Mild: [HIGH], Moderate: [HIGH, MID], Severe: [HIGH, MID, LOW] };

const isVowel = (ch) => "aeiouy".includes(ch.normalize("NFD")[0].toLowerCase());

function classifyVi(text, dialect) {
  const single = { ...VI_SINGLE };
  if (dialect === "south") { single.d = LOW; single.r = LOW; }
  const runs = [];
  let i = 0;
  while (i < text.length) {
    const low3 = text.substr(i, 3).toLowerCase();
    const low2 = text.substr(i, 2).toLowerCase();
    let m = null;
    for (const [cl, band] of VI_CLUSTERS) {
      if ((cl.length === 3 && low3 === cl) || (cl.length === 2 && low2 === cl)) { m = [text.substr(i, cl.length), band]; i += cl.length; break; }
    }
    if (m) { runs.push(m); continue; }
    const ch = text[i];
    if (isVowel(ch)) runs.push([ch, VOWEL]);
    else if (single[ch.toLowerCase()]) runs.push([ch, single[ch.toLowerCase()]]);
    else runs.push([ch, OTHER]);
    i++;
  }
  return runs;
}

function tokensVi(text, level, dialect) {
  const drop = DROP_BANDS[level] || [];
  return classifyVi(text, dialect).map(([seg, band]) => {
    if (drop.includes(band)) return { t: seg, cls: "hide" };
    if (band === VOWEL && level === "Severe") return { t: seg, cls: "fade" };
    return { t: seg, cls: "" };
  });
}

// --- EN cũ ---
const EN_MILD = new Set("sfzxvSFZXV");
const EN_MOD = new Set("tkcpgdhbđqTKCPGDHBĐQ");
const EN_SEV = new Set("mnlrwjyMNLRWJY0123456789");
function tokensEn(text, level) {
  const out = [];
  let i = 0;
  while (i < text.length) {
    const two = text.substr(i, 2).toLowerCase();
    const three = text.substr(i, 3).toLowerCase();
    if (three === "ght" && (level === "Moderate" || level === "Severe")) { out.push({ t: "   ", cls: "hide" }); i += 3; continue; }
    if (["th", "sh", "ph", "kh"].includes(two)) { out.push({ t: "  ", cls: "hide" }); i += 2; continue; }
    if (["ch", "tr", "gh"].includes(two) && (level === "Moderate" || level === "Severe")) { out.push({ t: "  ", cls: "hide" }); i += 2; continue; }
    const ch = text[i];
    if (level === "Mild" && EN_MILD.has(ch)) out.push({ t: ch, cls: "hide" });
    else if (level === "Moderate" && (EN_MILD.has(ch) || EN_MOD.has(ch))) out.push({ t: ch, cls: "hide" });
    else if (level === "Severe") out.push((EN_MILD.has(ch) || EN_MOD.has(ch) || EN_SEV.has(ch)) ? { t: ch, cls: "hide" } : { t: ch, cls: "fade" });
    else out.push({ t: ch, cls: "" });
    i++;
  }
  return out;
}

export function degradeTokens(text, level, lang = "vi", dialect = "north") {
  if (level === "Normal") return [{ t: text, cls: "" }];
  return lang === "vi" ? tokensVi(text, level, dialect) : tokensEn(text, level);
}
