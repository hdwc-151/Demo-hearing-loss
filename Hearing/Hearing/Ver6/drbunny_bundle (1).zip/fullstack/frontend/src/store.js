// State trung tâm (zustand) — nguồn chân lý duy nhất cho cả 3 tab.
import { create } from "zustand";
import { LEVEL_PRESETS } from "./data/constants";

export const useStore = create((set) => ({
  tab: "simulator",          // simulator | chat | audiogram
  lang: "vi",                // vi | en
  scenario: "shopping",
  dialect: "north",          // north | south (ảnh hưởng phân band d, r)
  level: "Normal",
  audiogramMode: "SOUNDS",   // SOUNDS | PLOTS
  thresholds: [...LEVEL_PRESETS.Normal],
  isPlaying: false,

  setTab: (tab) => set({ tab }),
  toggleLang: () => set((s) => ({ lang: s.lang === "vi" ? "en" : "vi" })),
  setScenario: (scenario) => set({ scenario }),
  toggleDialect: () => set((s) => ({ dialect: s.dialect === "north" ? "south" : "north" })),
  setLevel: (level) => set({ level, thresholds: [...LEVEL_PRESETS[level]] }),
  setMode: (audiogramMode) => set({ audiogramMode }),
  setThreshold: (idx, db) =>
    set((s) => {
      if (s.thresholds[idx] === db) return s;
      const t = [...s.thresholds];
      t[idx] = db;
      return { thresholds: t };
    }),
  setPlaying: (isPlaying) => set({ isPlaying }),
}));
