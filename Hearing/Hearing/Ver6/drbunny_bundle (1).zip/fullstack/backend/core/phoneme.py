"""Phoneme Visual Degradation — làm biến mất chữ theo tần số âm vị (Speech Banana).

Hỗ trợ 2 ngôn ngữ:
  - EN: giữ engine cũ (set ký tự Latin).
  - VI: engine mới theo NGỮ ÂM TIẾNG VIỆT (R-04) — tách grapheme cluster trước,
        phân band tần số theo loại âm, giữ nguyên âm + thanh điệu lâu nhất.

Cơ sở (Speech Banana cho tiếng Việt):
  HIGH  (2–8 kHz, năng lượng yếu — mất TRƯỚC, từ mức Mild):
        âm xát/bật hơi: ph /f/, th /tʰ/, kh /x/, x /s/, s /ʂ~s/, h /h/, v /v/,
        r /ʐ~z/, d /z/ (giọng Bắc).
  MID   (1–2 kHz — mất từ mức Moderate):
        âm tắc/tắc-xát: tr, ch, qu, t, c, k, q, p.
  LOW   (250–1000 Hz, năng lượng lớn — chỉ mất ở mức Severe):
        âm mũi & vang: ngh, ng, nh, gh, g, m, n, l; âm tắc hữu thanh: b, đ.
  Nguyên âm (a ă â e ê i o ô ơ u ư y + mọi dấu thanh): giữ lâu nhất,
        ở Severe chỉ làm mờ (fade) chứ không xoá — mô phỏng việc não còn bắt
        được "giai điệu thanh điệu" (F0 ~80–250 Hz) dù mất phụ âm.

GIỚI HẠN ĐÃ BIẾT (ghi ở BUILD_LOG R-04):
  - "gi" /z/ và "d" /z/ là đặc trưng giọng Bắc; giọng Nam d,gi,r → /j/ (xấp xỉ, band thấp)
    -> tham số `dialect`.
  - Không phân biệt vị trí đầu/cuối âm tiết: phụ âm cuối tiếng Việt chỉ gồm
    p,t,c,ch,m,n,ng,nh — bản này xử theo loại âm, chưa theo vị trí.
  - "gi" không tách thành cluster /z/ để tránh xoá nhầm nguyên âm (vd "gì"): 'g' xếp band
    LOW, 'i' giữ làm nguyên âm — chấp nhận lệch band cho trường hợp này.
"""
import re
import unicodedata
from typing import List, Dict

LEVELS = ["Normal", "Mild", "Moderate", "Severe"]

# ----- ENGINE EN (giữ nguyên bản cũ) -----
_EN_MILD_DIGRAPHS = ["th", "sh", "ph", "kh"]
_EN_MOD_DIGRAPHS = ["ght", "ch", "tr", "gh"]
_EN_MILD = set("sfzxv")
_EN_MOD = set("tkcpgdhbđq")
_EN_SEV = set("mnlrwjy0123456789")


def _blank(m: re.Match) -> str:
    return " " * len(m.group(0))


def _degrade_en(text: str, level: str) -> str:
    res = text
    for p in _EN_MILD_DIGRAPHS:
        res = re.sub(p, _blank, res, flags=re.IGNORECASE)
    if level in ("Moderate", "Severe"):
        for p in _EN_MOD_DIGRAPHS:
            res = re.sub(p, _blank, res, flags=re.IGNORECASE)
    out = []
    for ch in res:
        low = ch.lower()
        drop = ((level == "Mild" and low in _EN_MILD)
                or (level == "Moderate" and (low in _EN_MILD or low in _EN_MOD))
                or (level == "Severe" and (low in _EN_MILD or low in _EN_MOD or low in _EN_SEV)))
        out.append(" " if drop else ch)
    return "".join(out)


# ----- ENGINE VI (mới) -----
HIGH, MID, LOW, VOWEL, OTHER = "HIGH", "MID", "LOW", "VOWEL", "OTHER"

# cluster xếp dài trước để match đúng (ngh trước ng trước n...)
_VI_CLUSTERS = [
    ("ngh", LOW), ("ng", LOW), ("nh", LOW), ("gh", LOW),
    ("ph", HIGH), ("th", HIGH), ("kh", HIGH),
    ("tr", MID), ("ch", MID), ("qu", MID),
]
_VI_SINGLE = {
    "x": HIGH, "s": HIGH, "h": HIGH, "v": HIGH, "r": HIGH, "d": HIGH,
    "t": MID, "c": MID, "k": MID, "q": MID, "p": MID,
    "g": LOW, "m": LOW, "n": LOW, "l": LOW, "b": LOW, "đ": LOW,
}
_DROP_BANDS = {"Mild": {HIGH}, "Moderate": {HIGH, MID}, "Severe": {HIGH, MID, LOW}}


def _is_vowel(ch: str) -> bool:
    """Nguyên âm tiếng Việt = ký tự mà gốc (sau khi bỏ dấu) ∈ a e i o u y."""
    base = unicodedata.normalize("NFD", ch)[0].lower()
    return base in "aeiouy"


def classify_vi_char_run(text: str, dialect: str = "north"):
    """Tách text thành các (chuỗi, band). Dùng cho cả hiển thị lẫn kiểm thử."""
    single = dict(_VI_SINGLE)
    if dialect == "south":  # d, r → /j/ (xấp xỉ band thấp)
        single["d"] = LOW
        single["r"] = LOW
    runs = []
    i = 0
    while i < len(text):
        matched = None
        low3 = text[i:i + 3].lower()
        low2 = text[i:i + 2].lower()
        for cl, band in _VI_CLUSTERS:
            if (len(cl) == 3 and low3 == cl) or (len(cl) == 2 and low2 == cl):
                matched = (text[i:i + len(cl)], band)
                i += len(cl)
                break
        if matched:
            runs.append(matched)
            continue
        ch = text[i]
        if _is_vowel(ch):
            runs.append((ch, VOWEL))
        elif ch.lower() in single:
            runs.append((ch, single[ch.lower()]))
        else:
            runs.append((ch, OTHER))  # dấu câu, khoảng trắng, số...
        i += 1
    return runs


def _degrade_vi(text: str, level: str, dialect: str = "north") -> str:
    drop = _DROP_BANDS[level]
    out = []
    for seg, band in classify_vi_char_run(text, dialect):
        if band in drop:
            out.append(" " * len(seg))
        else:
            out.append(seg)  # nguyên âm & âm còn lại giữ nguyên (fade xử ở frontend)
    return "".join(out)


def degrade_text(text: str, level: str, lang: str = "vi", dialect: str = "north") -> str:
    if level == "Normal" or level not in LEVELS:
        return text
    return _degrade_vi(text, level, dialect) if lang == "vi" else _degrade_en(text, level)


def band_summary(text: str, dialect: str = "north") -> Dict[str, int]:
    """Đếm số âm vị theo band — tiện kiểm thử/giải thích."""
    counts = {HIGH: 0, MID: 0, LOW: 0, VOWEL: 0, OTHER: 0}
    for _, band in classify_vi_char_run(text, dialect):
        counts[band] += 1
    return counts
