// Phoneme Visual Degradation phía client (tức thì, không cần gọi API).
// Trả về danh sách token để React render: {t, cls} với cls = '' | 'hide' | 'fade'.
const MILD = new Set("sfzxvSFZXV");
const MOD = new Set("tkcpgdhbđqTKCPGDHBĐQ");
const SEV = new Set("mnlrwjyMNLRWJY0123456789");

export function degradeTokens(text, level) {
  if (level === "Normal") return [{ t: text, cls: "" }];
  const out = [];
  let i = 0;
  while (i < text.length) {
    const two = text.substr(i, 2).toLowerCase();
    const three = text.substr(i, 3).toLowerCase();
    if (three === "ght" && (level === "Moderate" || level === "Severe")) { out.push({ t: "   ", cls: "hide" }); i += 3; continue; }
    if (["th", "sh", "ph", "kh"].includes(two)) { out.push({ t: "  ", cls: "hide" }); i += 2; continue; }
    if (["ch", "tr", "gh"].includes(two) && (level === "Moderate" || level === "Severe")) { out.push({ t: "  ", cls: "hide" }); i += 2; continue; }

    const ch = text[i];
    if (level === "Mild" && MILD.has(ch)) out.push({ t: ch, cls: "hide" });
    else if (level === "Moderate" && (MILD.has(ch) || MOD.has(ch))) out.push({ t: ch, cls: "hide" });
    else if (level === "Severe") {
      if (MILD.has(ch) || MOD.has(ch) || SEV.has(ch)) out.push({ t: ch, cls: "hide" });
      else out.push({ t: ch, cls: "fade" });
    } else out.push({ t: ch, cls: "" });
    i++;
  }
  return out;
}
