// Client gọi backend FastAPI. Mặc định qua proxy '/api' (vite.config.js).
// Mọi hàm đều có fallback để UI không chết khi backend offline.
const BASE = import.meta.env.VITE_API_BASE || "/api";

export async function askDrBunny(audiogramDb, question) {
  try {
    const r = await fetch(`${BASE}/graphrag`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ audiogram_db: audiogramDb, question }),
    });
    if (!r.ok) throw new Error(r.status);
    return await r.json();
  } catch (e) {
    return { answer: "⚠️ Không gọi được backend — đang chạy ở chế độ offline. Hãy bật FastAPI (cổng 8000).", mode: "offline", error: String(e) };
  }
}

// Trả URL WAV nhiễu từ backend; null nếu offline để caller tự dựng nhiễu local.
export function noiseUrl(scenario, level, seconds = 3, seed) {
  const q = new URLSearchParams({ scenario, level, seconds: String(seconds) });
  if (seed != null) q.set("seed", String(seed));
  return `${BASE}/noise?${q.toString()}`;
}

export async function health() {
  try {
    const r = await fetch(`${BASE}/health`);
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}
