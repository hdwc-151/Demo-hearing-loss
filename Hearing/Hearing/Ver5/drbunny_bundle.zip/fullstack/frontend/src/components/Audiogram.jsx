import { useRef } from "react";
import { useStore } from "../store";
import { FREQS, SOUND_ITEMS } from "../data/constants";

// --- hàm chiếu toạ độ (port từ prototype, giữ nguyên viewBox 460x330) ---
const freqToX = (f) => ((Math.log2(f) - Math.log2(200)) / (Math.log2(9000) - Math.log2(200))) * 410 + 20;
const dbToY = (db) => ((db + 10) / 120) * 285 + 20;
const yToDb = (y) => Math.max(-10, Math.min(110, Math.round((((y - 20) / 285) * 120 - 10) / 5) * 5));

function userThresholdAt(freq, th) {
  if (freq <= FREQS[0]) return th[0];
  if (freq >= FREQS[FREQS.length - 1]) return th[FREQS.length - 1];
  for (let i = 0; i < FREQS.length - 1; i++) {
    if (freq >= FREQS[i] && freq <= FREQS[i + 1]) {
      const t = (Math.log2(freq) - Math.log2(FREQS[i])) / (Math.log2(FREQS[i + 1]) - Math.log2(FREQS[i]));
      return th[i] + t * (th[i + 1] - th[i]);
    }
  }
  return 20;
}

function playTone(freq, db) {
  const Ctx = window.AudioContext || window.webkitAudioContext;
  const ctx = new Ctx();
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.frequency.value = freq;
  osc.type = "sine";
  g.gain.value = Math.min(0.4, Math.pow(10, (db - 90) / 40));
  osc.connect(g); g.connect(ctx.destination);
  osc.start(); osc.stop(ctx.currentTime + 0.35);
}

export default function Audiogram() {
  const { thresholds, audiogramMode, setMode, setThreshold } = useStore();
  const svgRef = useRef(null);
  const rafRef = useRef(null);

  // HF-1: throttle kéo bằng requestAnimationFrame
  const onDrag = (idx) => (e) => {
    e.currentTarget.setPointerCapture?.(e.pointerId);
    const move = (ev) => {
      const y = ev.clientY;
      if (rafRef.current) return;
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = null;
        const rect = svgRef.current.getBoundingClientRect();
        const relY = ((y - rect.top) / rect.height) * 330;
        setThreshold(idx, yToDb(relY));
      });
    };
    const up = () => {
      if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const points = FREQS.map((f, i) => `${freqToX(f)},${dbToY(thresholds[i])}`).join(" ");
  const audibleCount = SOUND_ITEMS.filter((it) => it.db >= userThresholdAt(it.freq, thresholds)).length;

  return (
    <div>
      <h1 className="text-2xl font-extrabold mb-3">Interactive Audiogram</h1>

      <div className="flex w-60 mx-auto mb-3 rounded-full bg-bgcard p-1 border border-sage-light">
        {["PLOTS", "SOUNDS"].map((m) => (
          <button key={m} onClick={() => setMode(m)}
            className={`flex-1 py-2 rounded-full text-sm font-bold ${audiogramMode === m ? "bg-sage-dark text-white" : "text-sage-mid"}`}>
            {m}
          </button>
        ))}
      </div>

      <p className="text-center text-xs font-bold mb-1">
        Frequency (Hz) — <i className="font-normal">Kéo các điểm tròn cam lên/xuống để đổi ngưỡng nghe</i>
      </p>

      {/* board: svg + overlay phủ đúng vùng vẽ (HF-3) */}
      <div className="relative rounded-2xl bg-bgcard border border-sage-light overflow-hidden"
           style={{ height: 370, padding: "16px 10px 16px 36px" }}>
        <svg ref={svgRef} width="100%" height="100%" viewBox="0 0 460 330"
             style={{ overflow: "visible", position: "relative", zIndex: 4 }}>
          {Array.from({ length: 12 }, (_, k) => k * 10).map((db) => (
            <g key={db}>
              <line x1="15" y1={dbToY(db)} x2="440" y2={dbToY(db)} stroke="#DCE8D5" strokeWidth="1" />
              {db % 20 === 0 && <text x="-18" y={dbToY(db) + 4} fontSize="10" fill="#6C786A" fontWeight="600">{db}</text>}
            </g>
          ))}
          {FREQS.map((f) => (
            <g key={f}>
              <line x1={freqToX(f)} y1="15" x2={freqToX(f)} y2="310" stroke="#DCE8D5" strokeWidth="1" />
              <text x={freqToX(f)} y="8" fontSize="10" textAnchor="middle" fill="#6C786A" fontWeight="700">{f}</text>
            </g>
          ))}
          <polyline points={points} fill="none" stroke="#C87A51" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
          {FREQS.map((f, i) => (
            <circle key={f} cx={freqToX(f)} cy={dbToY(thresholds[i])} r="8"
              fill="#FAFBF8" stroke="#C87A51" strokeWidth="3"
              style={{ cursor: "ns-resize", touchAction: "none" }} onPointerDown={onDrag(i)} />
          ))}
        </svg>

        {audiogramMode === "SOUNDS" && (
          <div style={{ position: "absolute", top: 16, left: 36, right: 10, bottom: 16, zIndex: 5, pointerEvents: "none" }}>
            {SOUND_ITEMS.map((it) => {
              const th = userThresholdAt(it.freq, thresholds);
              const audible = it.db >= th;
              return (
                <div key={it.id}
                  className={`sound-item ${audible ? "" : "inaudible"}`}
                  title={`${it.label} | Ngưỡng của bạn: ${Math.round(th)}dB → ${audible ? "NGHE ĐƯỢC" : "ĐÃ XÁM HOÁ"}`}
                  onClick={() => audible && playTone(it.freq, it.db)}
                  style={{
                    position: "absolute", transform: "translate(-50%,-50%)", pointerEvents: "auto",
                    cursor: "pointer", textAlign: "center",
                    left: `${(freqToX(it.freq) / 460) * 100}%`, top: `${(dbToY(it.db) / 330) * 100}%`,
                  }}>
                  {it.emoji
                    ? <span style={{ fontSize: 26 }}>{it.emoji}</span>
                    : <span className="text-[13px] font-extrabold text-blue-500 bg-white/75 px-1.5 py-0.5 rounded">{it.text}</span>}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex gap-3 mt-3 text-xs">
        <div className="flex-1 bg-bgcard p-2.5 rounded-xl text-center font-semibold">
          Air Conduction<br /><span className="text-blue-500">○ Trái</span> <span className="text-line">✕ Phải</span>
        </div>
        <div className="flex-1 bg-bgcard p-2.5 rounded-xl text-center font-semibold">
          Trạng thái âm thanh<br />
          <span className="text-sage-dark">Nghe rõ: {audibleCount}/{SOUND_ITEMS.length} nhóm</span>
        </div>
      </div>
    </div>
  );
}
