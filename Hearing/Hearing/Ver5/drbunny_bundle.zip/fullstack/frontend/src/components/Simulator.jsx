import { useRef } from "react";
import { useStore } from "../store";
import { SCENARIOS, LEVELS, LEVEL_CUTOFF } from "../data/constants";
import { degradeTokens } from "../util/phoneme";
import { noiseUrl } from "../api";

export default function Simulator() {
  const { scenario, setScenario, level, setLevel, lang, toggleLang, isPlaying, setPlaying } = useStore();
  const ctxRef = useRef(null);
  const srcRef = useRef(null);

  const text = SCENARIOS[scenario][lang];
  const tokens = degradeTokens(text, level);

  async function start() {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = ctxRef.current || new Ctx();
    ctxRef.current = ctx;
    if (ctx.state === "suspended") await ctx.resume();

    // nhiễu nền: lấy WAV từ backend (engine procedural/GAN). Lỗi -> bỏ qua, chỉ đọc giọng.
    try {
      const buf = await fetch(noiseUrl(scenario, level, 3)).then((r) => r.arrayBuffer());
      const audioBuf = await ctx.decodeAudioData(buf);
      const src = ctx.createBufferSource();
      src.buffer = audioBuf; src.loop = true;
      const lp = ctx.createBiquadFilter();
      lp.type = "lowpass"; lp.frequency.value = LEVEL_CUTOFF[level];
      const g = ctx.createGain(); g.gain.value = 1;
      src.connect(lp); lp.connect(g); g.connect(ctx.destination);
      src.start();
      srcRef.current = src;
    } catch (e) {
      console.warn("Noise backend offline, chỉ đọc giọng:", e);
    }

    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang === "vi" ? "vi-VN" : "en-US";
      u.volume = level === "Severe" ? 0.22 : level === "Moderate" ? 0.48 : level === "Mild" ? 0.75 : 1.0;
      u.rate = 0.95;
      u.onend = stop;
      window.speechSynthesis.speak(u);
    }
    setPlaying(true);
  }

  function stop() {
    try { srcRef.current?.stop(); } catch {}
    srcRef.current = null;
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    setPlaying(false);
  }

  return (
    <div>
      <h1 className="text-2xl font-extrabold mb-3">Hearing Loss Simulator</h1>

      <div className="flex justify-center gap-2.5 mb-3">
        <select value={scenario} onChange={(e) => setScenario(e.target.value)}
          className="bg-sage-mid text-white font-bold text-sm px-6 py-2.5 rounded-full border-2 border-sage-dark uppercase">
          {Object.entries(SCENARIOS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <button onClick={toggleLang} className="bg-bgcard text-sage-dark border border-sage-mid px-3 rounded-full text-xs font-bold">
          {lang.toUpperCase()}
        </button>
      </div>

      <h2 className="text-lg font-bold mb-2">Visualization</h2>
      <div className="bg-bgcard rounded-2xl p-5 min-h-[260px] leading-relaxed text-[15px] whitespace-pre-wrap">
        {tokens.map((tk, i) =>
          tk.cls === "hide" ? <span key={i} style={{ opacity: 0 }}>{tk.t}</span>
          : tk.cls === "fade" ? <span key={i} className="char-fade-sev">{tk.t}</span>
          : <span key={i}>{tk.t}</span>
        )}
      </div>

      <h2 className="text-lg font-bold mt-4 mb-2">Hearing Loss Level</h2>
      <div className="flex justify-between items-center relative px-2">
        <div className="absolute left-3 right-3 top-1/2 h-1 bg-sage-light -z-0" />
        {LEVELS.map((lv) => (
          <button key={lv} onClick={() => setLevel(lv)}
            className={`z-10 rounded-full border-[3px] border-white transition-all ${level === lv ? "bg-sage-mid w-7 h-7" : "bg-accent w-6 h-6"}`}
            title={lv} />
        ))}
      </div>
      <div className="flex justify-between text-xs font-semibold mt-2">
        {LEVELS.map((lv) => <span key={lv}>{lv}</span>)}
      </div>

      <div className="flex flex-col items-center gap-2 mt-5">
        <button onClick={isPlaying ? stop : start}
          className="w-16 h-16 rounded-full bg-sage-mid border-[3px] border-sage-dark text-white text-2xl flex items-center justify-center">
          {isPlaying ? "⏸" : "▶"}
        </button>
        <p className="text-xs text-sage-mid font-semibold text-center">
          {isPlaying ? `Đang mô phỏng ${level} (cutoff ${LEVEL_CUTOFF[level]}Hz + nhiễu backend)` : "Bấm ▶ để nghe giọng qua bộ lọc DSP + nhiễu"}
        </p>
      </div>
    </div>
  );
}
