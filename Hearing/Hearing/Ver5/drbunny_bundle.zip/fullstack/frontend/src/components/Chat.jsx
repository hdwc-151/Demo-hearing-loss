import { useState } from "react";
import { useStore } from "../store";
import { FREQS } from "../data/constants";
import { askDrBunny } from "../api";

const PILLS = [
  { key: "analyze", label: "📊 Phân tích biểu đồ của tôi", q: "Phân tích biểu đồ thính lực hiện tại của tôi" },
  { key: "letters", label: "🔤 Vì sao chữ cái biến mất?", q: "Tại sao chữ cái biến mất ở mức Mild và Moderate?" },
  { key: "noisy", label: "🛒 Nghe tiếng nhưng không rõ chữ?", q: "Tại sao ở siêu thị tôi nghe tiếng nhưng không rõ chữ?" },
  { key: "family", label: "👨‍👩‍👧 Người nhà nên nói thế nào?", q: "Người nhà nên giao tiếp thế nào cho dễ nghe?" },
];

export default function Chat() {
  const { thresholds } = useStore();
  const [msgs, setMsgs] = useState([
    { role: "bot", text: "🐰 Xin chào! Mình là Bác sĩ Thỏ. Mình đọc trực tiếp biểu đồ thính lực của bạn. Chọn câu hỏi nhanh hoặc nhập câu bất kỳ nhé!" },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);

  const audiogramDb = Object.fromEntries(FREQS.map((f, i) => [String(f), thresholds[i]]));

  async function send(q) {
    if (!q.trim() || busy) return;
    setMsgs((m) => [...m, { role: "user", text: q }]);
    setInput("");
    setBusy(true);
    const res = await askDrBunny(audiogramDb, q);
    setMsgs((m) => [...m, { role: "bot", text: res.answer, meta: res.mode }]);
    setBusy(false);
  }

  return (
    <div>
      <h1 className="text-2xl font-extrabold mb-3">Dr. Bunny AI Audiologist</h1>

      <div className="bg-bgcard rounded-2xl p-4 h-[360px] overflow-y-auto flex flex-col gap-3">
        {msgs.map((m, i) => (
          <div key={i}
            className={`max-w-[85%] px-3.5 py-3 rounded-2xl text-sm leading-normal ${m.role === "bot" ? "bg-white self-start rounded-bl-sm shadow-sm" : "bg-sage-dark text-white self-end rounded-br-sm"}`}>
            {m.text}
            {m.meta && m.meta !== "hardcoded" && <span className="block mt-1 text-[10px] opacity-60">[{m.meta}]</span>}
          </div>
        ))}
        {busy && <div className="self-start text-xs text-sage-mid">🐰 đang soạn…</div>}
      </div>

      <div className="flex flex-wrap gap-1.5 mt-2.5">
        {PILLS.map((p) => (
          <button key={p.key} onClick={() => send(p.q)}
            className="bg-white border border-sage-mid text-sage-dark px-3 py-1.5 rounded-full text-xs font-semibold">
            {p.label}
          </button>
        ))}
      </div>

      <div className="flex gap-2 mt-2.5">
        <input value={input} onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send(input)}
          placeholder="Hỏi Bác sĩ Thỏ (GraphRAG)…"
          className="flex-1 px-3.5 py-2.5 rounded-full border border-sage-light outline-none" />
        <button onClick={() => send(input)} className="bg-sage-dark text-white px-4 rounded-full font-bold">Gửi</button>
      </div>
    </div>
  );
}
