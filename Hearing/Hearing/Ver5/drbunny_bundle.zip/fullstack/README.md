# Dr. Bunny — Full-Stack Scaffold (Giai đoạn B)

Tách từ prototype `index.html` thành `/frontend` (React + Vite + Tailwind) và
`/backend` (FastAPI). Giữ nguyên 100% logic lõi: rụng chữ theo âm vị, audiogram 2
chế độ PLOTS/SOUNDS với masking xám, chat Dr. Bunny hybrid.

## Cấu trúc
```
fullstack/
├── backend/                 # FastAPI
│   ├── main.py              # routes
│   ├── core/
│   │   ├── constants.py     # FREQS, presets, scenarios, sound items (nguồn chân lý)
│   │   ├── phoneme.py       # rụng chữ theo tần số âm vị
│   │   ├── graphrag.py      # KG + retrieve + system prompt + LLM (fallback hardcoded)
│   │   └── noise.py         # sinh nhiễu WAV (procedural; hook GAN) + mix SNR
│   └── requirements.txt
└── frontend/                # React + Vite + Tailwind
    └── src/
        ├── store.js         # state trung tâm (zustand) cho cả 3 tab
        ├── api.js           # gọi backend (có fallback offline)
        ├── data/constants.js# bản sao hằng số (đồng bộ với backend)
        ├── util/phoneme.js  # rụng chữ phía client (tức thì)
        └── components/      # Simulator.jsx, Audiogram.jsx, Chat.jsx
```

## Chạy
**Backend** (cổng 8000):
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
**Frontend** (cổng 5173, proxy `/api` -> 8000):
```bash
cd frontend
npm install
npm run dev
```
Mở http://localhost:5173

## Bật LLM thật cho chat (tầng 2, tuỳ chọn)
Đặt biến môi trường trước khi chạy backend:
```bash
export LLM_API_KEY=...            # bắt buộc để bật tầng 2
export LLM_BASE_URL=https://open.bigmodel.cn/api/paas/v4   # mặc định GLM
export LLM_MODEL=glm-4-flash
```
Không có key -> chat tự lùi về tầng 1 (hardcoded, đọc trực tiếp audiogram).

## Bật GAN thật cho nhiễu (tuỳ chọn)
`export GAN_CKPT=/path/to/generator.pt` + cài `torch` + có file kiến trúc
`gan_model.py`. Không có -> dùng nhiễu procedural (FFT lowpass + nhấn dải kịch bản).

## Trạng thái
Xem `../BUILD_LOG.md` mục 6c. Tóm tắt: backend test pass toàn bộ, frontend build
sạch, e2e (React → proxy → FastAPI) đã verify. Chưa có: checkpoint GAN thật (R-01),
chuẩn âm vị tiếng Việt (R-04), test trên thiết bị thật.
