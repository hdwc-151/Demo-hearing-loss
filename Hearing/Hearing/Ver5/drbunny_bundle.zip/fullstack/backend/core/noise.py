"""Sinh nhiễu môi trường theo kịch bản + cấp độ, trả về WAV (16-bit PCM).

Hai đường:
- GAN thật: nếu có torch + checkpoint (env GAN_CKPT). Kiến trúc để ở backend_core gốc.
- Fallback thủ tục (mặc định): FFT lowpass + nhấn dải tần kịch bản + điều biên babble.

R-01: hiện CHƯA có checkpoint GAN -> luôn chạy fallback. Đủ cho demo, chưa phải nhiễu
phi tĩnh học từ dữ liệu thật."""
import io
import os
import wave
import numpy as np

from .constants import SCENARIOS, LEVEL_CUTOFF, LEVEL_NOISE_GAIN

SR = 22050  # sample rate


def _procedural_noise(scenario: str, level: str, seconds: float, seed: int | None) -> np.ndarray:
    cfg = SCENARIOS.get(scenario, {"noise_freq": 1000, "noise_q": 1.0})
    cutoff = LEVEL_CUTOFF.get(level, 8000)
    gain = LEVEL_NOISE_GAIN.get(level, 0.1)

    n = int(SR * seconds)
    rng = np.random.default_rng(seed)
    x = rng.standard_normal(n)

    # --- FFT: lowpass theo cấp độ + nhấn dải tần đặc trưng kịch bản ---
    X = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(n, 1.0 / SR)
    X[freqs > cutoff] = 0.0  # brickwall lowpass (mất dải cao như ốc tai tổn thương)
    # nhấn quanh noise_freq bằng gaussian trên trục log, bề rộng theo Q
    fc = cfg["noise_freq"]
    q = max(cfg["noise_q"], 0.1)
    with np.errstate(divide="ignore"):
        logf = np.log2(np.where(freqs > 0, freqs, 1))
    emphasis = 1.0 + 1.5 * np.exp(-((logf - np.log2(fc)) ** 2) * (q * 2.0))
    X *= emphasis
    y = np.fft.irfft(X, n=n)

    # --- điều biên kiểu babble (nhiễu phi tĩnh nhẹ) ---
    t = np.arange(n) / SR
    env = 0.6 + 0.4 * np.sin(2 * np.pi * 0.8 * t) * np.sin(2 * np.pi * 0.17 * t)
    y *= env

    # chuẩn hoá rồi scale theo gain cấp độ
    peak = np.max(np.abs(y)) or 1.0
    y = (y / peak) * gain
    return y.astype(np.float32)


def _gan_noise(scenario: str, level: str, seconds: float, seed: int | None):
    """Chỉ chạy khi có torch + checkpoint. Trả None nếu không khả dụng -> caller fallback."""
    ckpt = os.getenv("GAN_CKPT")
    if not ckpt or not os.path.exists(ckpt):
        return None
    try:
        import torch
        from .constants import SCENARIO_IDX
        from gan_model import AcousticNoiseGeneratorGAN  # nạp kiến trúc gốc nếu có
    except Exception:
        return None
    try:
        g = AcousticNoiseGeneratorGAN()
        g.load_state_dict(torch.load(ckpt, map_location="cpu"))
        g.eval()
        if seed is not None:
            torch.manual_seed(seed)
        z = torch.randn(1, 64)
        idx = torch.tensor([SCENARIO_IDX.get(scenario, 0)])
        with torch.no_grad():
            wav = g(z, idx).squeeze().numpy().astype(np.float32)
        gain = LEVEL_NOISE_GAIN.get(level, 0.1)
        peak = np.max(np.abs(wav)) or 1.0
        return (wav / peak) * gain
    except Exception:
        return None


def _to_wav_bytes(y: np.ndarray) -> bytes:
    pcm = np.clip(y, -1.0, 1.0)
    pcm = (pcm * 32767).astype("<i2")
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


def generate_wav(scenario: str, level: str, seconds: float = 3.0, seed: int | None = None) -> tuple[bytes, str]:
    """Trả (wav_bytes, engine). engine = 'gan' hoặc 'procedural'."""
    seconds = max(0.5, min(seconds, 10.0))
    y = _gan_noise(scenario, level, seconds, seed)
    engine = "gan"
    if y is None:
        y = _procedural_noise(scenario, level, seconds, seed)
        engine = "procedural"
    return _to_wav_bytes(y), engine


def mix_snr(speech: np.ndarray, noise: np.ndarray, snr_db: float) -> np.ndarray:
    """Trộn speech + noise theo SNR (công thức blueprint mục 2.2). Cùng chiều dài."""
    n = min(len(speech), len(noise))
    s, no = speech[:n], noise[:n]
    ps = np.mean(s ** 2) or 1e-9
    pn = np.mean(no ** 2) or 1e-9
    k = np.sqrt(ps / (pn * (10 ** (snr_db / 10))))
    return s + k * no
