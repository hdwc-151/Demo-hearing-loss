"""Phoneme Visual Degradation — làm biến mất chữ theo tần số âm vị (Speech Banana).
Port + dọn lại từ backend_core.py. Giữ khoảng trắng để câu không co lại.

LƯU Ý R-04: các set dưới đây vẫn trộn quy ước Anh–Việt, CHƯA chuẩn âm vị học
tiếng Việt (đ, gh, ngh, tr, kh...). Đây là bản scaffold, cần chuyên gia ngữ âm rà."""
import re
from typing import List

LEVELS = ["Normal", "Mild", "Moderate", "Severe"]

# digraph xử lý trước ký tự đơn để bắt đúng cụm
MILD_DIGRAPHS = ["th", "sh", "ph", "kh"]
MOD_DIGRAPHS = ["ght", "ch", "tr", "gh"]  # ght đặt trước để match 3 ký tự

MILD_CHARS = set("sfzxv")
MOD_CHARS = set("tkcpgdhbđq")
SEV_CHARS = set("mnlrwjy0123456789")


def _blank(m: re.Match) -> str:
    return " " * len(m.group(0))


def degrade_text(text: str, level: str) -> str:
    if level == "Normal" or level not in LEVELS:
        return text

    res = text
    # tầng Mild trở lên: xoá digraph tần số cao
    for p in MILD_DIGRAPHS:
        res = re.sub(p, _blank, res, flags=re.IGNORECASE)
    # tầng Moderate trở lên: xoá thêm digraph trung-cao
    if level in ("Moderate", "Severe"):
        for p in MOD_DIGRAPHS:
            res = re.sub(p, _blank, res, flags=re.IGNORECASE)

    out: List[str] = []
    for ch in res:
        low = ch.lower()
        drop = (
            (level == "Mild" and low in MILD_CHARS)
            or (level == "Moderate" and (low in MILD_CHARS or low in MOD_CHARS))
            or (level == "Severe" and (low in MILD_CHARS or low in MOD_CHARS or low in SEV_CHARS))
        )
        out.append(" " if drop else ch)
    return "".join(out)
