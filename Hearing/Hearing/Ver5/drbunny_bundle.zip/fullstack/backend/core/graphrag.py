"""GraphRAG tối giản + System Prompt an toàn y tế cho Dr. Bunny.
Tầng 1 (fallback hardcoded) luôn chạy. Tầng 2 chỉ bật khi có LLM_API_KEY."""
import os
from typing import Dict, List, Optional

AUDIOLOGY_KG = {
    "nodes": [
        {
            "id": "HIGH_FREQ_LOSS",
            "freq_range": [2000, 8000],
            "phonemes": ["s", "x", "f", "ph", "th", "sh", "t", "k", "ch", "p"],
            "sounds": ["chim hót", "tiếng thì thầm", "giọng trẻ em và phụ nữ"],
            "symptoms": "Nghe thấy người khác nói nhưng không phân biệt rõ từ, hay nhầm từ gần vần.",
            "advice": "Đề nghị người nói nhìn thẳng mặt để đọc khẩu hình, nói chậm, tránh nói vọng từ phòng khác.",
        },
        {
            "id": "LOW_MID_FREQ_LOSS",
            "freq_range": [250, 1000],
            "phonemes": ["m", "n", "ng", "b", "d", "a", "o", "u", "e"],
            "sounds": ["nước nhỏ giọt", "bước chân", "chó sủa trầm"],
            "symptoms": "Âm thanh chung nhỏ đi rõ rệt ngay cả trong phòng yên tĩnh.",
            "advice": "Nên đo thính lực lâm sàng tại chuyên khoa Tai-Mũi-Họng để kiểm tra dẫn truyền khí và xương.",
        },
    ]
}


def retrieve_context(audiogram_db: Dict[str, int]) -> str:
    """Truy xuất node từ đồ thị tri thức theo ngưỡng nghe hiện tại."""
    high = (audiogram_db["2000"] + audiogram_db["4000"] + audiogram_db["8000"]) / 3.0
    low = (audiogram_db["250"] + audiogram_db["500"] + audiogram_db["1000"]) / 3.0
    blocks = [f"PTA trầm-trung (250–1000Hz): {low:.1f} dB HL | PTA cao (2000–8000Hz): {high:.1f} dB HL."]
    if high > 30:
        n = AUDIOLOGY_KG["nodes"][0]
        blocks.append(
            f"[{n['id']}] Âm vị khuyết: {', '.join(n['phonemes'])}. "
            f"Âm khó nghe: {', '.join(n['sounds'])}. Triệu chứng: {n['symptoms']} Lời khuyên: {n['advice']}"
        )
    if low > 30:
        n = AUDIOLOGY_KG["nodes"][1]
        blocks.append(f"[{n['id']}] Âm vị ảnh hưởng: {', '.join(n['phonemes'])}. Lời khuyên: {n['advice']}")
    return "\n".join(blocks)


def build_system_prompt(audiogram_db: Dict[str, int]) -> str:
    ctx = retrieve_context(audiogram_db)
    return (
        "Bạn là Bác sĩ Thỏ (Dr. Bunny), chuyên gia tư vấn thính học AI ấm áp.\n"
        f"Dữ liệu GraphRAG của người dùng:\n{ctx}\n\n"
        "QUY TẮC BẮT BUỘC:\n"
        "1. CHỈ dựa vào dữ liệu GraphRAG ở trên để giải thích; không bịa thêm.\n"
        "2. TUYỆT ĐỐI không chẩn đoán bệnh. Luôn nhấn mạnh đây là công cụ mô phỏng & sàng lọc tham khảo.\n"
        "3. Giải thích ngắn gọn, dễ hiểu cho cả người lớn tuổi lẫn con cháu."
    )


def _fallback_answer(audiogram_db: Dict[str, int], question: str) -> str:
    """Tầng 1: trả lời bằng chính dữ liệu đồ thị, không cần API."""
    high = round((audiogram_db["2000"] + audiogram_db["4000"] + audiogram_db["8000"]) / 3)
    low = round((audiogram_db["250"] + audiogram_db["500"] + audiogram_db["1000"]) / 3)
    msg = (f"🐰 [Hardcoded] Ngưỡng của bạn — trầm-trung: {low} dB HL, cao: {high} dB HL. ")
    if high > 40:
        msg += ("Tần số cao bị kéo xuống nên các phụ âm s, f, th, x, t, k, ch dễ 'rụng' khỏi câu nói. "
                "Hãy nhờ người nói nhìn thẳng mặt và nói chậm rõ.")
    elif high > 25:
        msg += "Bắt đầu chớm mất vài phụ âm xát tần số cao ở môi trường ồn."
    else:
        msg += "Dải cao còn tốt, bạn nghe rõ hầu hết phụ âm."
    msg += " (Đây là mô phỏng & sàng lọc tham khảo, không thay chẩn đoán bác sĩ.)"
    return msg


def answer(audiogram_db: Dict[str, int], question: Optional[str]) -> dict:
    """Trả về context + câu trả lời. Dùng LLM nếu có LLM_API_KEY, ngược lại fallback."""
    ctx = retrieve_context(audiogram_db)
    q = (question or "").strip()
    api_key = os.getenv("LLM_API_KEY")
    if not api_key or not q:
        return {"context": ctx, "answer": _fallback_answer(audiogram_db, q), "mode": "hardcoded"}
    try:
        reply = _call_llm(build_system_prompt(audiogram_db), q, api_key)
        return {"context": ctx, "answer": reply, "mode": "llm"}
    except Exception as e:  # LLM lỗi -> không để sập, lùi về fallback
        return {"context": ctx, "answer": _fallback_answer(audiogram_db, q),
                "mode": "hardcoded", "llm_error": str(e)}


def _call_llm(system_prompt: str, user_q: str, api_key: str) -> str:
    """Nối LLM tương thích OpenAI (GLM-4-Flash / Gemini qua proxy / v.v.).
    Cấu hình qua env: LLM_BASE_URL, LLM_MODEL."""
    import httpx
    base = os.getenv("LLM_BASE_URL", "https://open.bigmodel.cn/api/paas/v4")
    model = os.getenv("LLM_MODEL", "glm-4-flash")
    r = httpx.post(
        f"{base}/chat/completions",
        headers={"Authorization": f"Bearer {api_key}"},
        json={"model": model, "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_q},
        ], "temperature": 0.4},
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]
