// State trung tâm (zustand) — nguồn chân lý duy nhất cho cả 3 tab.
// R-06: dữ liệu số (freqs, presets, sound items, cutoff) lấy từ BACKEND lúc mount
// (store.cfg). constants.js chỉ còn là FALLBACK khi offline.
import { create } from "zustand";
import { FREQS, LEVEL_PRESETS, LEVEL_CUTOFF, SOUND_ITEMS } from "./data/constants";

const FALLBACK_CFG = { freqs: FREQS, levelPresets: LEVEL_PRESETS, cutoff: LEVEL_CUTOFF, soundItems: SOUND_ITEMS, source: "local" };

export const useStore = create((set, get) => ({
  tab: "simulator",          // simulator | chat | audiogram
  lang: "vi",                // vi | en
  scenario: "shopping",
  dialect: "north",          // north | south (ảnh hưởng phân band d, r)
  level: "Normal",
  audiogramMode: "SOUNDS",   // SOUNDS | PLOTS
  cfg: FALLBACK_CFG,         // nguồn hằng số hiện dùng (local hoặc backend)
  thresholds: [...LEVEL_PRESETS.Normal],
  isPlaying: false,

  // ghi đè hằng số bằng dữ liệu backend; giữ nguyên thresholds nếu level chưa đổi
  applyConfig: (partial) =>
    set((s) => {
      const cfg = { ...s.cfg, ...partial, source: "backend" };
      const preset = cfg.levelPresets?.[s.level];
      return { cfg, thresholds: preset ? [...preset] : s.thresholds };
    }),

  setTab: (tab) => set({ tab }),
  toggleLang: () => set((s) => ({ lang: s.lang === "vi" ? "en" : "vi" })),
  setScenario: (scenario) => set({ scenario }),
  toggleDialect: () => set((s) => ({ dialect: s.dialect === "north" ? "south" : "north" })),
  setLevel: (level) => set((s) => ({ level, thresholds: [...(s.cfg.levelPresets[level] || LEVEL_PRESETS[level])] })),
  setMode: (audiogramMode) => set({ audiogramMode }),
  setThreshold: (idx, db) =>
    set((s) => {
      if (s.thresholds[idx] === db) return s;
      const t = [...s.thresholds];
      t[idx] = db;
      return { thresholds: t };
    }),
  setPlaying: (isPlaying) => set({ isPlaying }),
}));
