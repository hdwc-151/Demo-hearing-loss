import { useEffect } from "react";
import { useStore } from "./store";
import { getConfig } from "./api";
import Simulator from "./components/Simulator";
import Chat from "./components/Chat";
import Audiogram from "./components/Audiogram";

const TABS = [
  { id: "simulator", label: "🎧 Simulator", el: <Simulator /> },
  { id: "chat", label: "💬 Chat", el: <Chat /> },
  { id: "audiogram", label: "📈 Audiogram", el: <Audiogram /> },
];

export default function App() {
  const { tab, setTab, applyConfig, cfg } = useStore();

  // R-06: nạp hằng số từ backend lúc mount; offline thì giữ fallback local.
  useEffect(() => {
    getConfig().then((c) => { if (c) applyConfig(c); });
  }, [applyConfig]);

  return (
    <div className="flex justify-center min-h-screen pb-24">
      <div className="w-full max-w-[540px] px-4 pt-5">
        {TABS.find((t) => t.id === tab)?.el}
      </div>

      <div onClick={() => setTab("chat")}
        className="fixed bottom-20 text-4xl cursor-pointer z-20"
        style={{ left: "max(16px, calc(50% - 255px))" }} title="Hỏi Bác sĩ Thỏ">🐰🩺</div>

      <nav className="fixed bottom-0 inset-x-0 h-16 bg-bgcard border-t border-sage-light flex justify-center z-30">
        <div className="w-full max-w-[540px] flex justify-around items-center">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-1.5 text-sm font-bold px-4 py-2 rounded-xl ${tab === t.id ? "text-[#232B22] bg-sage-mid/15" : "text-sage-mid"}`}>
              {t.label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
