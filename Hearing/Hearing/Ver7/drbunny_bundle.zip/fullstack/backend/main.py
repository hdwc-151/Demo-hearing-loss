"""Dr. Bunny API — FastAPI.
Chạy: uvicorn main:app --reload --port 8000  (từ thư mục backend/)

Endpoints:
  GET  /health
  GET  /scenarios            -> danh sách kịch bản + cấu hình
  GET  /sound-items          -> 13 nhóm âm thanh (Hz, dB) cho audiogram
  GET  /presets              -> FREQS + preset 4 cấp
  POST /degrade              -> làm rụng chữ theo cấp độ
  POST /graphrag             -> context + câu trả lời Dr. Bunny (LLM nếu có key)
  GET  /noise                -> WAV nhiễu theo scenario + level
"""
from typing import Dict, Optional

from fastapi import FastAPI, Response, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from core import constants, phoneme, graphrag, noise

app = FastAPI(title="Dr. Bunny API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # scaffold: nới lỏng; siết lại khi deploy
    allow_methods=["*"],
    allow_headers=["*"],
)


class DegradeReq(BaseModel):
    text: str
    level: str = "Normal"
    lang: str = "vi"
    dialect: str = "north"


class GraphRagReq(BaseModel):
    audiogram_db: Dict[str, int]
    question: Optional[str] = None


@app.get("/health")
def health():
    return {"status": "ok", "service": "dr-bunny", "version": app.version}


@app.get("/scenarios")
def scenarios():
    return constants.SCENARIOS


@app.get("/sound-items")
def sound_items():
    return constants.SOUND_ITEMS


@app.get("/presets")
def presets():
    return {"freqs": constants.FREQS, "level_presets": constants.LEVEL_PRESETS,
            "cutoff": constants.LEVEL_CUTOFF}


@app.post("/degrade")
def degrade(req: DegradeReq):
    return {
        "level": req.level,
        "lang": req.lang,
        "degraded": phoneme.degrade_text(req.text, req.level, req.lang, req.dialect),
        "bands": phoneme.band_summary(req.text, req.dialect) if req.lang == "vi" else None,
    }


@app.post("/graphrag")
def graphrag_ep(req: GraphRagReq):
    return graphrag.answer(req.audiogram_db, req.question)


@app.get("/noise")
def noise_ep(
    scenario: str = Query("shopping"),
    level: str = Query("Normal"),
    seconds: float = Query(3.0, ge=0.5, le=10.0),
    seed: Optional[int] = Query(None),
):
    wav, engine = noise.generate_wav(scenario, level, seconds, seed)
    return Response(content=wav, media_type="audio/wav",
                    headers={"X-Noise-Engine": engine})
